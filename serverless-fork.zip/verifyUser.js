const sgMail = require("@sendgrid/mail");
const dotenv = require("dotenv");
const winston = require("winston");

// Load environment variables
dotenv.config();

// Configure SendGrid API
// sgMail.setApiKey("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");
sgMail.setApiKey(process.env.SENDGRID_API_KEY);

// Configure logging with Winston to log both to the console and a file
const logger = winston.createLogger({
  level: "info",
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.printf(({ timestamp, level, message }) => {
      return `${timestamp} - ${level.toUpperCase()}: ${message}`;
    })
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: "csye6225application.log" }),
  ],
});

exports.handler = async (event) => {
  const baseURL = process.env.BASE_URL;

  try {
    for (const record of event.Records) {
      const snsMessage = JSON.parse(record.Sns.Message);
      const userEmail = snsMessage.user_email;
      const userId = snsMessage.user_id;
      const verificationToken = snsMessage.verification_token;
      const apiVersion = snsMessage.apiVersion || 'v1';

      // const verificationLink = `http://${baseURL}/v1/user/self/verify?token=${userId}`;
      const verificationLink = `http://${baseURL}/${apiVersion}/user/self/verify?token=${verificationToken}`;

      const msg = {
        to: userEmail,
        from: `noreply@${baseURL}`,        
        // from: `noreply@dev.desaihir.me`,        
        subject: "CSYE6225 Webapp - Verify Your Email",
        html: `
        <div style="font-family: Arial, sans-serif; line-height: 1.5; color: #333;">
          <h2 style="color: #0056b3;">Welcome to CSYE6225 Webapp!</h2>
          <p>Dear Valued User,</p>
          <p>
            Thank you for registering with us. To complete your account setup, please verify your email address. 
            Click the link below to confirm your email and activate your account:
          </p>
          <p>
            <a 
              href="${verificationLink}" 
              style="display: inline-block; background-color: #0056b3; color: #fff; text-decoration: none; padding: 10px 15px; border-radius: 5px; font-weight: bold;">
              Verify Email
            </a>
          </p>
          <p style="font-size: 0.9em; color: #555;">
            Note: This verification link will expire in <strong>2 minutes</strong>. Please complete the verification process promptly.
          </p>
          <p>
            If you did not initiate this request, please disregard this email or contact us if you have any concerns.
          </p>
          <p>Best regards,</p>
          <p><strong>Hir Desai</strong></p>
          <p style="font-size: 0.8em; color: #888;">
            CSYE6225 Webapp Team<br>
            <a href="mailto:support@${baseURL}" style="color: #0056b3;">support@${baseURL}</a>
          </p>
        </div>
      `,
      };

      try {
        const response = await sgMail.send(msg);
        logger.info(
          `Email sent to ${userEmail} with status code: ${response[0].statusCode}`
        );
      } catch (error) {
        logger.error(`Failed to send email to ${userEmail}: ${error}`);
        return {
          statusCode: 500,
          body: "Email sending failed",
        };
      }
    }

    return {
      statusCode: 200,
      body: "Verification email sent successfully",
    };
  } catch (error) {
    logger.error(`Error processing the verification: ${error}`);
    return {
      statusCode: 500,
      body: "An error occurred",
    };
  }
};

